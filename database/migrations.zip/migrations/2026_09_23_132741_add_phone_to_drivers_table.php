<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('boat_drivers', function (Blueprint $table) {
        $table->foreign('driver_id')
              ->references('id')
              ->on('driver_boats')
              ->cascadeOnDelete();
    });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('boat_drivers', function (Blueprint $table) {
            //
        });
    }
};
