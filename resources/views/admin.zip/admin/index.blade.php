@extends('admin.main')

@section('page_title', 'Dashboard')

@section('body')

@php
    $firstName = auth()->check() ? (explode(' ', auth()->user()->name)[0] ?? auth()->user()->name) : 'Allen';

    $statCards = [
        ['label' => 'Visits',      'value' => '32,451', 'change' => '+14.00(+0.50%)'],
        ['label' => 'Impressions', 'value' => '15,236', 'change' => '+138.97(+0.54%)'],
        ['label' => 'Conversion',  'value' => '7,688',  'change' => '+57.62(+0.76%)'],
        ['label' => 'Downloads',   'value' => '1,553',  'change' => '+138.97(+0.54%)'],
    ];

    $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug'];
    $revenue = [55, 62, 50, 95, 118, 122, 95, 128];
    $sales   = [10, 18, 15, 30, 42, 55, 48, 50];

    $radarLabels = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug'];
    $radarSales  = [80, 90, 70, 85, 60, 75, 65, 88];
    $radarOrders = [95, 80, 88, 95, 78, 60, 70, 92];

    $bottomStats = [
        ['label' => 'Total Revenue', 'value' => '$1,12,038', 'change' => '+1.37%', 'up' => true],
        ['label' => 'Transaction', 'value' => '12,42,236', 'change' => '-2.87%', 'up' => false],
        ['label' => 'Website Audience Metrics', 'value' => '48,254', 'change' => '+3.45%', 'up' => true],
    ];
@endphp

<div class="mb-6 flex flex-wrap items-center justify-between gap-3 pt-2">
    <div class="flex flex-wrap items-center gap-x-6 gap-y-1">
        <h1 class="text-xl font-bold text-gray-800">Dashboard</h1>
        <nav class="flex items-center gap-5 text-sm text-gray-500">
            <a href="#" class="hover:text-gray-800">ICE Market data</a>
            <a href="#" class="hover:text-gray-800">Own analysis</a>
            <a href="#" class="hover:text-gray-800">Historic market data</a>
        </nav>
    </div>
    <nav class="flex items-center gap-5 text-sm text-gray-500">
        <a href="#" class="hover:text-gray-800">Settings</a>
        <a href="#" class="hover:text-gray-800">Analytics</a>
        <a href="#" class="hover:text-gray-800">Watchlist</a>
    </nav>
</div>

<!-- Toolbar -->
<div class="mb-6 flex flex-wrap items-center gap-3 rounded-xl bg-white p-3 shadow-sm">
    <div class="flex items-center gap-2 rounded-lg bg-gray-50 px-3 py-2 text-sm font-medium text-gray-600">
        <button type="button" class="text-gray-400 hover:text-gray-600">&lsaquo;</button>
        <span>03/02/2019 - 20/08/2019</span>
        <button type="button" class="text-gray-400 hover:text-gray-600">&rsaquo;</button>
    </div>
    <select class="rounded-lg border border-gray-200 bg-gray-50 px-3 py-2 text-sm font-medium text-gray-600 focus:outline-none">
        <option>All Day</option>
        <option>Today</option>
        <option>This Week</option>
    </select>
    <a href="#" class="text-sm font-semibold text-[#3b49df]">Advanced Options</a>
    <button type="button" class="rounded-lg bg-[#3b49df] px-5 py-2 text-sm font-semibold text-white shadow-sm hover:bg-[#2f3bc4]">New</button>
    <div class="ml-auto">
        <button type="button" class="flex items-center gap-2 rounded-lg border border-gray-200 px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-50">
            Export
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2" class="h-4 w-4">
                <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5" />
            </svg>
        </button>
    </div>
</div>

<!-- Stat row -->
<div class="mb-6 grid grid-cols-1 gap-px overflow-hidden rounded-2xl bg-gray-100 shadow-sm sm:grid-cols-2 lg:grid-cols-4">
    @foreach ($statCards as $s)
        <div class="flex items-center justify-between gap-4 bg-white p-6">
            <div>
                <p class="text-2xl font-extrabold text-gray-800">{{ $s['value'] }}</p>
                <p class="mt-1 text-sm font-semibold text-[#3b49df]">{{ $s['label'] }}</p>
                <p class="mt-0.5 text-xs text-gray-400">{{ $s['change'] }}</p>
            </div>
            <canvas class="h-12 w-20 shrink-0 spark" data-values="{{ implode(',', range(5, 40, 3)) }}"></canvas>
        </div>
    @endforeach
</div>

<!-- Charts row -->
<div class="grid grid-cols-1 gap-6 lg:grid-cols-3">

    <!-- Sales Statistics Overview -->
    <div class="rounded-2xl bg-white p-6 shadow-sm lg:col-span-2">
        <div class="flex flex-wrap items-start justify-between gap-3">
            <div>
                <h3 class="text-base font-bold text-gray-800">Sales Statistics Overview</h3>
                <p class="text-xs text-gray-400">Lorem ipsum is placeholder text commonly used</p>
            </div>
            <div class="flex items-center gap-1 rounded-lg bg-gray-50 p-1 text-xs font-semibold text-gray-400">
                <button type="button" class="rounded-md bg-white px-3 py-1.5 text-[#3b49df] shadow-sm">1D</button>
                <button type="button" class="px-3 py-1.5 hover:text-gray-600">5D</button>
                <button type="button" class="px-3 py-1.5 hover:text-gray-600">1M</button>
                <button type="button" class="px-3 py-1.5 hover:text-gray-600">1Y</button>
            </div>
        </div>

        <div class="mt-5 flex flex-wrap items-center gap-10">
            <div>
                <p class="text-xs text-gray-400">Total Cost</p>
                <p class="mt-1 text-lg font-bold text-gray-800">15,263 <span class="text-xs font-medium text-gray-400">89.5% of 20,000 Total</span></p>
            </div>
            <div>
                <p class="text-xs text-gray-400">Total Revenue</p>
                <p class="mt-1 text-lg font-bold text-gray-800">$753,098 <span class="text-xs font-medium text-gray-400">10.5% of 20,000 Total</span></p>
            </div>
            <div class="ml-auto flex items-center gap-4 text-xs font-medium text-gray-500">
                <span class="flex items-center gap-1.5"><span class="h-2.5 w-2.5 rounded-full bg-[#3b49df]"></span> Revenue</span>
                <span class="flex items-center gap-1.5"><span class="h-2.5 w-2.5 rounded-full bg-emerald-400"></span> Sales</span>
            </div>
        </div>

        <div class="mt-4 h-64">
            <canvas id="salesChart"></canvas>
        </div>
    </div>

    <!-- Net Profit Margin -->
    <div class="rounded-2xl bg-white p-6 shadow-sm">
        <h3 class="text-base font-bold text-gray-800">Net Profit Margin</h3>
        <p class="text-xs text-gray-400">Started collecting data from February 2019</p>
        <div class="mt-3 flex items-center gap-4 text-xs font-medium text-gray-500">
            <span class="flex items-center gap-1.5"><span class="h-2.5 w-2.5 rounded-full bg-sky-400"></span> Sales</span>
            <span class="flex items-center gap-1.5"><span class="h-2.5 w-2.5 rounded-full bg-[#3b49df]"></span> Orders</span>
        </div>
        <div class="mt-4 h-64">
            <canvas id="radarChart"></canvas>
        </div>
    </div>
</div>

<!-- Bottom stats row -->
<div class="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
    @foreach ($bottomStats as $b)
        <div class="rounded-2xl bg-white p-6 shadow-sm">
            <p class="text-sm font-semibold text-gray-600">{{ $b['label'] }}</p>
            <div class="mt-2 flex items-center justify-between">
                <p class="text-2xl font-extrabold text-gray-800">{{ $b['value'] }}</p>
                <span class="rounded-full px-2 py-0.5 text-xs font-bold {{ $b['up'] ? 'bg-emerald-50 text-emerald-500' : 'bg-red-50 text-red-500' }}">
                    {{ $b['change'] }}
                </span>
            </div>
        </div>
    @endforeach
</div>

<script type="application/json" id="admin-chart-data">
    {"months": @json($months), "revenue": @json($revenue), "sales": @json($sales), "radarLabels": @json($radarLabels), "radarSales": @json($radarSales), "radarOrders": @json($radarOrders)}
</script>
@vite('resources/js/admin-charts.js')

@endsection
