<!DOCTYPE html>
<html lang="ar">
@php($isAccountingPage = request()->routeIs('accounting.*', 'accounts', 'trees'))
@php($isAccountingHelpPage = request()->routeIs('accounting.help'))
<head>
    @include('admin.layout.head')
</head>
<body class="bg-[#eef1f6] text-gray-900 antialiased">

    <div class="min-h-screen">

        @include('admin.layout.sidebar')

        <div class="flex min-h-screen flex-col lg:pl-64">

            @include('admin.layout.navbar')

            <main class="flex-1">
                <div class="mx-auto max-w-7xl px-4 pb-6 sm:px-6 lg:px-8 lg:pb-8">

                    @include('admin.layout.alert')

                    @hasSection('page_title')
                        <div class="mb-5 pt-2 text-right print:hidden" dir="rtl">
                            <h1 class="text-xl font-bold text-gray-800">@yield('page_title')</h1>
                        </div>
                    @endif

                    <div id="admin-page-content" dir="rtl" class="space-y-5 {{ $isAccountingPage ? 'accounting-page' : '' }}">
                        @yield('body')
                    </div>
                </div>
            </main>

            <footer class="border-t border-gray-200 bg-[#eef1f6] px-4 py-4 text-center text-xs text-gray-400 sm:px-6 lg:px-8 {{ $isAccountingHelpPage ? 'print:hidden' : '' }}">
                &copy; {{ date('Y') }} نظام المحاسبة
            </footer>

        </div>
    </div>

    <script src="{{ asset('js/app.js') }}"></script>
    @yield('scripts')
</body>
</html>
