@extends('admin.main')
@section('title')لوحة التحكم@endsection
@section('page_title')نظرة عامة@endsection
@section('body')

<section class="overflow-hidden rounded-2xl bg-gradient-to-l from-[#2836c9] via-[#3b49df] to-[#6571f2] px-6 py-7 text-white shadow-lg sm:px-8 sm:py-9">
  <div class="flex flex-col justify-between gap-6 sm:flex-row sm:items-center">
    <div>
      <p class="mb-2 text-sm font-medium text-indigo-100">النظام المحاسبي · {{ now()->translatedFormat('l، j F Y') }}</p>
      <h2 class="text-2xl font-extrabold tracking-tight sm:text-3xl">مرحبًا، {{ $user->full_name ?: $user->username }}</h2>
      <p class="mt-2 max-w-2xl text-sm leading-6 text-indigo-100 sm:text-base">تابع أداء حساباتك وحركة القيود، وانتقل بسرعة إلى أهم المهام المحاسبية.</p>
    </div>
    <a href="{{ route('accounting.journal') }}" class="inline-flex shrink-0 items-center justify-center gap-2 rounded-xl bg-white px-5 py-3 text-sm font-bold text-indigo-700 shadow-sm transition hover:bg-indigo-50 focus:outline-none focus:ring-4 focus:ring-white/30">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="h-5 w-5"><path stroke-linecap="round" stroke-linejoin="round" d="M12 5v14m-7-7h14"/></svg>
      إنشاء قيد جديد
    </a>
  </div>
</section>

<section aria-label="إحصائيات النظام" class="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-5">
  <article class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
    <div class="flex items-center justify-between">
      <span class="text-sm font-semibold text-slate-500">حسابات الدليل</span>
      <span class="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" class="h-5 w-5"><path stroke-linecap="round" stroke-linejoin="round" d="M4 5.75A1.75 1.75 0 0 1 5.75 4H20v14H5.75A1.75 1.75 0 0 0 4 19.75v-14ZM4 17.5c0-.966.784-1.75 1.75-1.75H20"/></svg>
      </span>
    </div>
    <p id="st-accounts" class="mt-5 text-3xl font-extrabold tracking-tight text-slate-800">—</p>
    <a href="{{ route('accounts') }}" class="mt-2 inline-flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-800">عرض الحسابات <span aria-hidden="true">←</span></a>
  </article>

  <article class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
    <div class="flex items-center justify-between">
      <span class="text-sm font-semibold text-slate-500">إجمالي القيود</span>
      <span class="flex h-10 w-10 items-center justify-center rounded-xl bg-sky-50 text-sky-600">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" class="h-5 w-5"><path stroke-linecap="round" stroke-linejoin="round" d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/></svg>
      </span>
    </div>
    <p id="st-entries" class="mt-5 text-3xl font-extrabold tracking-tight text-slate-800">—</p>
    <a href="{{ route('accounting.journal') }}" class="mt-2 inline-flex items-center gap-1 text-xs font-semibold text-sky-700 hover:text-sky-900">فتح دفتر اليومية <span aria-hidden="true">←</span></a>
  </article>

  <article class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
    <div class="flex items-center justify-between">
      <span class="text-sm font-semibold text-slate-500">إجمالي المدين المُرحّل</span>
      <span class="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" class="h-5 w-5"><path stroke-linecap="round" stroke-linejoin="round" d="M12 19V5m0 0-6 6m6-6 6 6"/></svg>
      </span>
    </div>
    <p id="st-debit" class="mt-5 break-words text-2xl font-extrabold tracking-tight text-slate-800">—</p>
    <p class="mt-2 text-xs text-slate-400">الحركات المرحلة فقط</p>
  </article>

  <article class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
    <div class="flex items-center justify-between">
      <span class="text-sm font-semibold text-slate-500">إجمالي الدائن المُرحّل</span>
      <span class="flex h-10 w-10 items-center justify-center rounded-xl bg-rose-50 text-rose-600">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" class="h-5 w-5"><path stroke-linecap="round" stroke-linejoin="round" d="M12 5v14m0 0 6-6m-6 6-6-6"/></svg>
      </span>
    </div>
    <p id="st-credit" class="mt-5 break-words text-2xl font-extrabold tracking-tight text-slate-800">—</p>
    <p class="mt-2 text-xs text-slate-400">الحركات المرحلة فقط</p>
  </article>

  <article class="rounded-2xl border border-amber-200 bg-amber-50/70 p-5 shadow-sm">
    <div class="flex items-center justify-between">
      <span class="text-sm font-semibold text-amber-800">قيود بانتظار الترحيل</span>
      <span class="flex h-10 w-10 items-center justify-center rounded-xl bg-white text-amber-600">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" class="h-5 w-5"><circle cx="12" cy="12" r="9"/><path stroke-linecap="round" stroke-linejoin="round" d="M12 7v5l3 2"/></svg>
      </span>
    </div>
    <p id="st-drafts" class="mt-5 text-3xl font-extrabold tracking-tight text-amber-900">—</p>
    <a href="{{ route('accounting.journal') }}" class="mt-2 inline-flex items-center gap-1 text-xs font-semibold text-amber-800 hover:text-amber-950">مراجعة المسودات <span aria-hidden="true">←</span></a>
  </article>
</section>

<section class="grid grid-cols-1 gap-5 xl:grid-cols-3">
  <article class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm xl:col-span-2">
    <div class="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 px-5 py-4 sm:px-6">
      <div>
        <h3 class="font-bold text-slate-800">أحدث القيود</h3>
        <p class="mt-1 text-xs text-slate-500">آخر الحركات المسجلة في النظام</p>
      </div>
      <a href="{{ route('accounting.journal') }}" class="inline-flex items-center gap-2 rounded-lg border border-slate-200 px-3 py-2 text-xs font-semibold text-slate-600 transition hover:border-indigo-200 hover:bg-indigo-50 hover:text-indigo-700">دفتر اليومية <span aria-hidden="true">←</span></a>
    </div>
    <div class="overflow-x-auto">
      <table class="min-w-full divide-y divide-slate-100 text-right text-sm">
        <thead class="bg-slate-50 text-xs font-semibold text-slate-500">
          <tr>
            <th scope="col" class="whitespace-nowrap px-5 py-3 sm:px-6">رقم الحركة</th>
            <th scope="col" class="whitespace-nowrap px-5 py-3">التاريخ</th>
            <th scope="col" class="min-w-40 px-5 py-3">البيان</th>
            <th scope="col" class="whitespace-nowrap px-5 py-3">المدين</th>
            <th scope="col" class="whitespace-nowrap px-5 py-3 sm:px-6">الحالة</th>
          </tr>
        </thead>
        <tbody id="recent-body" class="divide-y divide-slate-100 text-slate-700">
          <tr><td colspan="5" class="px-5 py-10 text-center text-sm text-slate-400">جارٍ تحميل القيود...</td></tr>
        </tbody>
      </table>
    </div>
  </article>

  <aside class="space-y-5">
    <article class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
      <div class="mb-5 flex items-center gap-3">
        <span class="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" class="h-5 w-5"><path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6.75h16.5v13.5H3.75zM7.5 3.75v6m9-6v6M3.75 10.5h16.5"/></svg>
        </span>
        <div>
          <h3 class="font-bold text-slate-800">الفترة المحاسبية</h3>
          <p class="mt-0.5 text-xs text-slate-500">إعدادات التقارير الحالية</p>
        </div>
      </div>
      <dl class="space-y-4">
        <div class="flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
          <dt class="text-sm text-slate-500">من</dt>
          <dd class="text-sm font-semibold text-slate-800">{{ $periodFrom }}</dd>
        </div>
        <div class="flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
          <dt class="text-sm text-slate-500">إلى</dt>
          <dd class="text-sm font-semibold text-slate-800">{{ $periodTo }}</dd>
        </div>
        <div class="flex items-start justify-between gap-4">
          <dt class="text-sm text-slate-500">الشركة</dt>
          <dd class="text-left text-sm font-semibold text-slate-800">{{ $companyName }}</dd>
        </div>
      </dl>
      @if($user->role === 'admin')
        <a href="{{ route('accounting.settings') }}" class="mt-5 inline-flex w-full items-center justify-center rounded-lg bg-slate-50 px-4 py-2.5 text-sm font-semibold text-slate-600 transition hover:bg-indigo-50 hover:text-indigo-700">إدارة إعدادات النظام</a>
      @endif
    </article>

    <article class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
      <div class="mb-4 flex items-center justify-between">
        <div>
          <h3 class="font-bold text-slate-800">الوصول السريع</h3>
          <p class="mt-1 text-xs text-slate-500">انتقال مباشر لأدوات المحاسبة</p>
        </div>
        <span class="text-lg text-indigo-500" aria-hidden="true">✦</span>
      </div>
      <div class="grid grid-cols-2 gap-3">
        <a href="{{ route('trees') }}" class="rounded-xl border border-slate-100 bg-slate-50 p-3 text-center transition hover:border-indigo-200 hover:bg-indigo-50">
          <span class="mb-1 block text-lg">🌳</span><span class="text-xs font-semibold text-slate-700">شجرة الحسابات</span>
        </a>
        <a href="{{ route('accounting.ledger') }}" class="rounded-xl border border-slate-100 bg-slate-50 p-3 text-center transition hover:border-indigo-200 hover:bg-indigo-50">
          <span class="mb-1 block text-lg">📖</span><span class="text-xs font-semibold text-slate-700">الأستاذ العام</span>
        </a>
        <a href="{{ route('accounting.trial-balance') }}" class="rounded-xl border border-slate-100 bg-slate-50 p-3 text-center transition hover:border-indigo-200 hover:bg-indigo-50">
          <span class="mb-1 block text-lg">⚖️</span><span class="text-xs font-semibold text-slate-700">ميزان المراجعة</span>
        </a>
        <a href="{{ route('accounting.income-statement') }}" class="rounded-xl border border-slate-100 bg-slate-50 p-3 text-center transition hover:border-indigo-200 hover:bg-indigo-50">
          <span class="mb-1 block text-lg">📊</span><span class="text-xs font-semibold text-slate-700">قائمة الدخل</span>
        </a>
      </div>
    </article>
  </aside>
</section>

@endsection

@section('scripts')
<script>
async function loadAccountingDashboard() {
  const body = $('#recent-body');

  try {
    const data = await api('/api/dashboard');
    $('#st-accounts').textContent = Number(data.stats.accounts).toLocaleString('en-US');
    $('#st-entries').textContent = Number(data.stats.entries).toLocaleString('en-US');
    $('#st-debit').textContent = fmt(data.stats.total_debit);
    $('#st-credit').textContent = fmt(data.stats.total_credit);
    $('#st-drafts').textContent = Number(data.stats.drafts).toLocaleString('en-US');

    if (!data.recent.length) {
      body.innerHTML = '<tr><td colspan="5" class="px-5 py-12 text-center text-sm text-slate-400 sm:px-6"><span class="mb-2 block text-3xl">📭</span>لا توجد قيود مسجلة بعد</td></tr>';
      return;
    }

    body.innerHTML = data.recent.map(entry => `
      <tr class="transition hover:bg-slate-50">
        <td class="whitespace-nowrap px-5 py-4 font-semibold tabular-nums text-slate-800 sm:px-6">${esc(entry.movement_no)}</td>
        <td class="whitespace-nowrap px-5 py-4 tabular-nums text-slate-500">${esc(fmtDate(entry.entry_date))}</td>
        <td class="max-w-xs truncate px-5 py-4 text-slate-700" title="${esc(entry.description || '')}">${esc(entry.description || 'بدون بيان')}</td>
        <td class="whitespace-nowrap px-5 py-4 font-medium tabular-nums text-slate-700">${esc(fmt(entry.total_debit))}</td>
        <td class="whitespace-nowrap px-5 py-4 sm:px-6">${entry.status === 'posted'
          ? '<span class="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-700"><span class="h-1.5 w-1.5 rounded-full bg-emerald-500"></span>مرحل</span>'
          : '<span class="inline-flex items-center gap-1.5 rounded-full bg-amber-50 px-2.5 py-1 text-xs font-semibold text-amber-700"><span class="h-1.5 w-1.5 rounded-full bg-amber-500"></span>مسودة</span>'}</td>
      </tr>`).join('');
  } catch (error) {
    body.innerHTML = '<tr><td colspan="5" class="px-5 py-10 text-center text-sm text-rose-600 sm:px-6">تعذر تحميل بيانات لوحة التحكم. يرجى تحديث الصفحة والمحاولة مرة أخرى.</td></tr>';
    toast(error.message, 'err');
  }
}

loadAccountingDashboard();
</script>
@endsection
