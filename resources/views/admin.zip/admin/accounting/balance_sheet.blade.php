@extends('admin.main')
@section('title')المركز المالي@endsection
@section('page_title')المركز المالي@endsection
@section('body')

<div class="panel">
  <div class="filters">
    <div class="field"><label>من تاريخ</label><input type="date" id="flt-from"></div>
    <div class="field"><label>إلى تاريخ</label><input type="date" id="flt-to"></div>
    <div class="field"><label>المنطقة</label>
      <select id="flt-region"><option value="">كل المناطق</option>
        @foreach($regions as $r)<option value="{{ $r }}">{{ $r }}</option>@endforeach
      </select></div>
    <button class="btn btn-teal" onclick="loadRep()">🔍 عرض المركز المالي</button>
    <a class="btn btn-gold" href="#" onclick="exportLink();return false;">📊 تصدير Excel</a>
  </div>

  <div id="result">
    <div class="empty-state"><div class="big">🏦</div>حدد التاريخ ثم اضغط «عرض المركز المالي»</div>
  </div>
</div>

@endsection

@section('scripts')
<script>
function qs() {
  const p = new URLSearchParams();
  if ($('#flt-from').value) p.set('from', $('#flt-from').value);
  if ($('#flt-to').value) p.set('to', $('#flt-to').value);
  if ($('#flt-region').value) p.set('region', $('#flt-region').value);
  return p.toString();
}

function exportLink() { location.href = '/balance-sheet/export.xlsx?' + qs(); }

function secRow(label) {
  return '<tr class="bg-indigo-50"><td colspan="3" class="px-4 py-3 font-bold text-indigo-800">' + esc(label) + '</td></tr>';
}
function totRow(label, val) {
  return '<tr class="bg-slate-50"><td colspan="2" class="text-center font-bold text-slate-700">' + esc(label) + '</td><td class="num font-semibold">' + (val === '' ? '' : fmt(val)) + '</td></tr>';
}

async function loadRep() {
  try {
    const d = await api('/api/balance-sheet?' + qs());
    const rows = [];
    rows.push(secRow('أولاً: الموجودات (الأصول)'));
    d.assets.forEach(r => {
      rows.push('<tr><td class="num">' + esc(r.acc_no) + '</td><td>' + esc(r.name) + '</td><td class="num">' + (r.amount ? fmt(r.amount) : '') + '</td></tr>');
    });
    rows.push(totRow('إجمالي الموجودات', d.assets_total));
    rows.push(secRow('ثانياً: الالتزامات وحقوق الملكية'));
    d.liabilities_equity.forEach(r => {
      rows.push('<tr><td class="num">' + esc(r.acc_no) + '</td><td>' + esc(r.name) + '</td><td class="num">' + (r.amount ? fmt(r.amount) : '') + '</td></tr>');
    });
    rows.push(totRow('إجمالي الالتزامات وحقوق الملكية (بدون الأرباح)', d.liab_equity_total));
    rows.push(totRow('الأرباح / (الخسائر) المتراكمة', d.net_cumulative));
    rows.push(totRow('إجمالي الالتزامات وحقوق الملكية (بعد الأرباح المتراكمة)', d.total_with_income));

    const badgeStyle = d.balanced
      ? '<span class="balance-pill ok">✔ المركز المالي متوازن — الموجودات = الالتزامات + حقوق الملكية</span>'
      : '<span class="balance-pill bad">✖ المركز المالي غير متوازن (فرق: ' + fmt(d.difference) + ')</span>';

    $('#result').innerHTML =
      '<div class="flex flex-wrap items-center gap-3 border-b border-slate-100 px-5 py-4">' + badgeStyle + '</div>' +
      '<div class="tbl-wrap"><table class="tbl">' +
      '<thead><tr><th class="num">رقم الحساب</th><th>البيان</th><th class="num">المبلغ</th></tr></thead>' +
      '<tbody>' + rows.join('') + '</tbody></table></div>';
  } catch (e) { toast(e.message, 'err'); }
}

$('#flt-from').value = '{{ $periodFrom }}';
$('#flt-to').value = '{{ $periodTo }}';
loadRep();
</script>
@endsection