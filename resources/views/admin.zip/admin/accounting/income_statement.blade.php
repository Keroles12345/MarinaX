@extends('admin.main')
@section('title')قائمة الدخل@endsection
@section('page_title')قائمة الدخل@endsection
@section('body')

<div class="panel">
  <div class="filters">
    <div class="field"><label>من تاريخ</label><input type="date" id="flt-from"></div>
    <div class="field"><label>إلى تاريخ</label><input type="date" id="flt-to"></div>
    <div class="field"><label>المنطقة</label>
      <select id="flt-region"><option value="">كل المناطق</option>
        @foreach($regions as $r)<option value="{{ $r }}">{{ $r }}</option>@endforeach
      </select></div>
    <button class="btn btn-teal" onclick="loadRep()">🔍 عرض قائمة الدخل</button>
    <a class="btn btn-gold" href="#" onclick="exportLink();return false;">📊 تصدير Excel</a>
  </div>

  <div id="result">
    <div class="empty-state"><div class="big">📈</div>حدد الفترة ثم اضغط «عرض قائمة الدخل»</div>
  </div>
</div>

@endsection

@section('scripts')
<script>
function qs() {
  const p = new URLSearchParams();
  if ($('#flt-from').value) p.set('from', $('#flt-from').value);
  if ($('#flt-to').value) p.set('to', $('#flt-to').value);
  if ($('#flt-region').value) p.set('region', $('#flt-region').value);
  return p.toString();
}

function exportLink() { location.href = '/income-statement/export.xlsx?' + qs(); }

function secRow(label) {
  return '<tr class="bg-indigo-50"><td colspan="3" class="px-4 py-3 font-bold text-indigo-800">' + esc(label) + '</td></tr>';
}
function totRow(label, val, cls) {
  const col = val !== null && val !== undefined ? '<td class="num">' + (val === '' ? '' : fmt(val)) + '</td>' : '<td></td>';
  return '<tr class="bg-slate-50"><td colspan="2" class="text-center font-bold text-slate-700">' + esc(label) + '</td>' + col + '</tr>';
}

async function loadRep() {
  try {
    const d = await api('/api/income-statement?' + qs());
    const rows = [];
    rows.push(secRow('أولاً: الإيرادات'));
    d.revenues.forEach(r => {
      rows.push('<tr><td class="num">' + esc(r.acc_no) + '</td><td>' + esc(r.name) + '</td><td class="num">' + (r.amount ? fmt(r.amount) : '') + '</td></tr>');
    });
    rows.push(totRow('إجمالي الإيرادات', d.revenues_total));
    rows.push(secRow('ثانياً: المصروفات'));
    d.expenses.forEach(r => {
      rows.push('<tr><td class="num">' + esc(r.acc_no) + '</td><td>' + esc(r.name) + '</td><td class="num">' + (r.amount ? fmt(r.amount) : '') + '</td></tr>');
    });
    rows.push(totRow('إجمالي المصروفات', d.expenses_total));
    const netCls = d.net >= 0 ? 'text-emerald-700' : 'text-rose-700';
    rows.push('<tr class="bg-indigo-50"><td colspan="2" class="text-center font-bold text-slate-800">صافي الدخل / (الخسارة)</td><td class="num font-bold ' + netCls + '">' + fmt(d.net) + '</td></tr>');

    $('#result').innerHTML = '<div class="tbl-wrap"><table class="tbl">' +
      '<thead><tr><th class="num">رقم الحساب</th><th>البيان</th><th class="num">المبلغ</th></tr></thead>' +
      '<tbody>' + rows.join('') + '</tbody></table></div>';
  } catch (e) { toast(e.message, 'err'); }
}

$('#flt-from').value = '{{ $periodFrom }}';
$('#flt-to').value = '{{ $periodTo }}';
loadRep();
</script>
@endsection