@extends('admin.main')
@section('title')سجل العمليات@endsection
@section('page_title')سجل العمليات@endsection
@section('body')

<div class="panel">
  <div class="panel-head"><h3>🛡️ آخر 300 عملية</h3></div>
  <div class="tbl-wrap">
    <table class="tbl">
      <thead><tr><th class="num">التاريخ والوقت</th><th>المستخدم</th><th>العملية</th><th>التفاصيل</th></tr></thead>
      <tbody>
        @forelse($logs as $l)
        <tr>
          <td class="num">{{ $l->at }}</td>
          <td>{{ $l->user }}</td>
          <td><span class="badge region">{{ $l->action }}</span></td>
          <td>{{ $l->details ?: '—' }}</td>
        </tr>
        @empty
        <tr><td colspan="4" class="empty-state">لا توجد عمليات مسجلة بعد</td></tr>
        @endforelse
      </tbody>
    </table>
  </div>
</div>

@endsection
