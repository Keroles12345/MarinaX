﻿@extends('admin.main')
@section('title')شجرة الحسابات@endsection
@section('page_title')شجرة الحسابات@endsection
@section('body')

<div class="panel">
  <div class="panel-head">
    <h3>🌳 هيكل الحسابات</h3>
    <div class="toolbar">
      <button class="btn btn-dark btn-sm" onclick="expandAll()">⬇️ تفريع الكل</button>
      <button class="btn btn-dark btn-sm" onclick="collapseAll()">⬆️ طي الكل</button>
      <a class="btn btn-gold btn-sm" href="/accounts">📚 العرض المسطح</a>
      @if($user->role === 'admin')
      <button class="btn btn-red btn-sm" onclick="wipeTree()">🗑️ مسح الشجرة كاملة</button>
      @endif
    </div>
  </div>
  <div class="tree-container" id="tree">
    <div class="rounded-xl border border-dashed border-slate-200 bg-slate-50 px-4 py-10 text-center text-sm text-slate-400">جارٍ تحميل شجرة الحسابات...</div>
  </div>
</div>

@endsection

@section('scripts')
<script>
let TREE = [];

async function loadTree() {
  try {
    const d = await api('/api/accounts/tree');
    TREE = d.tree;
    renderTree(TREE);
  } catch (e) { toast(e.message, 'err'); }
}

function renderTree(tree) {
  const c = $('#tree');
  c.innerHTML = tree.map(typeNode => `
    <div class="tree-node tree-type">
      <div class="tree-row cursor-pointer" onclick="toggleNext(this)">
        <span class="tw-arrow">▾</span>
        <span class="tw-icon">📁</span>
        <b>${esc(typeNode.type)}</b>
        <span class="tw-count">${countChildren(typeNode)} حساب</span>
      </div>
      <div class="tree-children">
        ${typeNode.children.map(g => `
          <div class="tree-node tree-group">
            <div class="tree-row cursor-pointer" onclick="toggleNext(this)">
              <span class="tw-arrow">▾</span>
              <span class="tw-icon">🗂️</span>
              <b>${esc(g.label)}</b>
              <span class="tw-count">${g.children.length} حساب</span>
            </div>
            <div class="tree-children">
              ${g.children.map(a => `
                <div class="tree-node tree-account">
                  <div class="tree-row">
                    <span class="tw-arrow tw-leaf">•</span>
                    <span class="tw-icon">📄</span>
                    <span class="tw-no">${esc(a.acc_no)}</span> — ${esc(a.name)}
                    ${a.budget > 0 ? `<span class="tw-budget">ميزانية: ${fmt(a.budget)}</span>` : ''}
                    @if($user->role !== 'viewer')
                    <span class="tree-act">
                      <button class="btn btn-sm btn-dark act-btn" title="تعديل" onclick='editAcc(${JSON.stringify({id: a.id, acc_no: a.acc_no, name: a.name, type: a.type, opening_balance: 0, budget: a.budget})})'>✏️</button>
                      <button class="btn btn-sm btn-red act-btn" title="حذف" onclick="delTreeAcc(${a.id}, '${esc(a.acc_no)}')">🗑️</button>
                    </span>
                    @endif
                  </div>
                </div>`).join('')}
            </div>
          </div>`).join('')}
      </div>
    </div>`).join('');
}

function countChildren(node) {
  return node.children.reduce((n, c) => n + (c.children ? c.children.length : 1), 0);
}

function toggleNext(row) {
  const kids = row.nextElementSibling;
  if (!kids) return;
  const isHidden = kids.style.display === 'none';
  kids.style.display = isHidden ? '' : 'none';
  const arrow = row.querySelector('.tw-arrow');
  if (arrow) arrow.textContent = isHidden ? '▾' : '▸';
}

function expandAll() {
  document.querySelectorAll('.tree-children').forEach(c => c.style.display = '');
  document.querySelectorAll('.tw-arrow').forEach(a => a.textContent = '▾');
}

function collapseAll() {
  document.querySelectorAll('.tree .tree-type > .tree-children').forEach(c => { c.style.display = ''; });
  document.querySelectorAll('.tree-children .tree-children').forEach(c => c.style.display = 'none');
  document.querySelectorAll('.tw-arrow').forEach(a => a.textContent = '▸');
  document.querySelectorAll('.tree-type > .tree-row .tw-arrow').forEach(a => a.textContent = '▾');
}

function editAcc(a) {
  window.location.href = '/accounts?q=' + encodeURIComponent(a.acc_no || '');
}

async function delTreeAcc(id, no) {
  if (!await confirmDlg(`حذف الحساب ${no}؟ لا يمكن الحذف إذا كان له حركات.`)) return;
  try { await api('/api/accounts/' + id, { method: 'DELETE' }); toast('تم حذف الحساب'); loadTree(); }
  catch (e) { toast(e.message, 'err'); }
}

async function wipeTree() {
  if (!await confirmDlg('تحذير نهائي ⚠️ هتحذف الشجرة كاملة (كل الحسابات وكل القيود) نهائيًا. متأكد؟')) return;
  if (!await confirmDlg('تأكيد أخير: نفّذ مسح الشجرة الآن؟ لا يمكن التراجع إلا بالنسخ الاحتياطي')) return;
  try {
    const d = await api('/api/accounts/wipe', { method: 'POST' });
    toast(`تم مسح الشجرة: ${d.deleted_accounts} حساب و${d.deleted_entries} قيد`);
    loadTree();
  } catch (e) { toast(e.message, 'err'); }
}

loadTree();
</script>
@endsection