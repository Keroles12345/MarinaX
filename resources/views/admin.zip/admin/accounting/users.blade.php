@extends('admin.main')
@section('title')المستخدمون@endsection
@section('page_title')إدارة المستخدمين@endsection
@section('body')

<div class="panel">
  <div class="panel-head">
    <h3>👥 المستخدمون (3 مستخدمين يعملون في نفس الوقت)</h3>
    <button class="btn btn-teal btn-sm" onclick="openModal('addModal')">➕ مستخدم جديد</button>
  </div>
  <div class="tbl-wrap">
    <table class="tbl">
      <thead><tr><th>الاسم</th><th class="num">اسم الدخول</th><th>الصلاحية</th><th>سؤال الأمان</th><th class="num">تاريخ الإضافة</th><th class="num">إجراءات</th></tr></thead>
      <tbody>
        @foreach($users as $u)
        <tr>
          <td>{{ $u->full_name }}</td>
          <td class="num">{{ $u->username }}</td>
          <td>@if($u->role === 'admin')<span class="badge posted">مدير النظام</span>
              @elseif($u->role === 'accountant')<span class="badge region">محاسب</span>
              @else<span class="badge gray">مشاهدة فقط</span>@endif</td>
          <td>@if($u->security_question)<span class="badge posted" title="{{ $u->security_question }}">مُفعّل</span>
              @else<span class="badge draft">بدون سؤال</span>@endif</td>
          <td class="num">{{ $u->created_at }}</td>
          <td class="num">
            <button class="btn btn-sm btn-dark" onclick="setSecurity({{ $u->id }}, '{{ $u->username }}', '{{ $u->security_question }}')">🛡️ سؤال أمان</button>
            <button class="btn btn-sm btn-teal" onclick="resetPw({{ $u->id }}, '{{ $u->username }}')">🔑 كلمة مرور</button>
            @if($u->id !== $user->id)
            <button class="btn btn-sm btn-red" onclick="delUser({{ $u->id }}, '{{ $u->username }}')">🗑️</button>
            @endif
          </td>
        </tr>
        @endforeach
      </tbody>
    </table>
  </div>
  <div class="panel-body hint">
    💡 سؤال الأمان يُفعّل «نسيت كلمة المرور؟» لصاحب الحساب حتى يستعيد دخوله بنفسه عند نسيان كلمة المرور.
    <br>💡 باقي أعضاء الفريق يفتحون السيستم من أجهزتهم عبر متصفح الإنترنت على عنوان: <b class="inline-block text-indigo-700" dir="ltr">http://IP-الجهاز-الرئيسي:5000</b>
  </div>
</div>

<!-- مودال إضافة مستخدم -->
<div class="modal-overlay" id="addModal">
  <div class="modal">
    <div class="modal-head"><h3>مستخدم جديد</h3><button class="modal-close" data-close-modal>×</button></div>
    <div class="modal-body">
      <div class="field"><label>الاسم الكامل *</label><input id="u-name" type="text"></div>
      <div class="field"><label>اسم الدخول *</label><input id="u-user" type="text" placeholder="بالإنجليزية"></div>
      <div class="field"><label>كلمة المرور *</label><input id="u-pass" type="text"></div>
      <div class="field"><label>سؤال الأمان (اختياري — لتفعيل «نسيت كلمة المرور؟»)</label><input id="u-q" type="text" placeholder="مثال: اسم مدرستك الثانوية؟"></div>
      <div class="field"><label>إجابة سؤال الأمان (اختياري)</label><input id="u-ans" type="text"></div>
      <div class="field"><label>الصلاحية</label>
        <select id="u-role">
          <option value="accountant">محاسب (كل الصلاحيات المحاسبية)</option>
          <option value="admin">مدير النظام</option>
          <option value="viewer">مشاهدة فقط</option>
        </select></div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-gold" onclick="addUser()">حفظ</button>
      <button class="btn btn-dark" data-close-modal>إلغاء</button>
    </div>
  </div>
</div>

<!-- مودال سؤال الأمان -->
<div class="modal-overlay" id="secModal">
  <div class="modal">
    <div class="modal-head"><h3 id="sec-title">سؤال الأمان</h3><button class="modal-close" data-close-modal>×</button></div>
    <div class="modal-body">
      <input type="hidden" id="sec-id">
      <div class="field"><label>سؤال الأمان</label><input id="sec-q" type="text" placeholder="مثال: اسم مدرستك الثانوية؟"></div>
      <div class="field"><label>إجابة سؤال الأمان</label><input id="sec-ans" type="text"></div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-gold" onclick="saveSecurity()">حفظ</button>
      <button class="btn btn-dark" data-close-modal>إلغاء</button>
    </div>
  </div>
</div>

<!-- مودال كلمة المرور -->
<div class="modal-overlay" id="pwModal">
  <div class="modal">
    <div class="modal-head"><h3 id="pw-title">كلمة مرور جديدة</h3><button class="modal-close" data-close-modal>×</button></div>
    <div class="modal-body">
      <input type="hidden" id="pw-id">
      <div class="field"><label>كلمة المرور الجديدة</label><input id="pw-new" type="text"></div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-gold" onclick="savePw()">تغيير</button>
      <button class="btn btn-dark" data-close-modal>إلغاء</button>
    </div>
  </div>
</div>

@endsection

@section('scripts')
<script>
async function addUser() {
  try {
    await api('/api/users', { method: 'POST', body: {
      full_name: $('#u-name').value.trim(),
      username: $('#u-user').value.trim(),
      password: $('#u-pass').value,
      role: $('#u-role').value,
      security_question: $('#u-q').value.trim(),
      security_answer: $('#u-ans').value.trim(),
    }});
    closeModal('addModal');
    toast('تمت إضافة المستخدم');
    setTimeout(() => location.reload(), 800);
  } catch (e) { toast(e.message, 'err'); }
}

function setSecurity(id, username, question) {
  $('#sec-title').textContent = `سؤال الأمان لـ ${username}`;
  $('#sec-id').value = id;
  $('#sec-q').value = question || '';
  $('#sec-ans').value = '';
  openModal('secModal');
}

async function saveSecurity() {
  const q = $('#sec-q').value.trim();
  const a = $('#sec-ans').value.trim();
  if (!q) return toast('اكتب سؤال الأمان', 'err');
  if (!a) return toast('اكتب إجابة سؤال الأمان', 'err');
  try {
    await api(`/api/users/${$('#sec-id').value}/security`, { method: 'POST', body: { security_question: q, security_answer: a } });
    closeModal('secModal');
    toast('تم حفظ سؤال الأمان');
    setTimeout(() => location.reload(), 800);
  } catch (e) { toast(e.message, 'err'); }
}

function resetPw(id, username) {
  $('#pw-title').textContent = `كلمة مرور جديدة لـ ${username}`;
  $('#pw-id').value = id;
  $('#pw-new').value = '';
  openModal('pwModal');
}

async function savePw() {
  try {
    await api(`/api/users/${$('#pw-id').value}/password`, { method: 'POST', body: { password: $('#pw-new').value } });
    closeModal('pwModal');
    toast('تم تغيير كلمة المرور');
  } catch (e) { toast(e.message, 'err'); }
}

async function delUser(id, username) {
  if (!await confirmDlg(`حذف المستخدم ${username}؟`)) return;
  try {
    await api('/api/users/' + id, { method: 'DELETE' });
    toast('تم حذف المستخدم');
    setTimeout(() => location.reload(), 700);
  } catch (e) { toast(e.message, 'err'); }
}
</script>
@endsection
