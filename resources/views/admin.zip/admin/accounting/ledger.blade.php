@extends('admin.main')
@section('title')الأستاذ العام@endsection
@section('page_title')الأستاذ العام@endsection
@section('body')

<div class="panel">
  <div class="filters">
    <div class="field"><label>الحساب *</label>
      <select id="flt-acc"><option value="">— اختر الحساب —</option></select></div>
    <div class="field"><label>من تاريخ</label><input type="date" id="flt-from"></div>
    <div class="field"><label>إلى تاريخ</label><input type="date" id="flt-to"></div>
    <div class="field"><label>المنطقة</label>
      <select id="flt-region"><option value="">كل المناطق</option>
        @foreach($regions as $r)<option value="{{ $r }}">{{ $r }}</option>@endforeach
      </select></div>
    <button class="btn btn-teal" onclick="loadLedger()">🔍 عرض الكشف</button>
    <a class="btn btn-gold" href="#" onclick="exportLink();return false;">📊 تصدير Excel</a>
  </div>

  <div id="result"></div>
</div>

@endsection

@section('scripts')
<script>
async function init() {
  try {
    const d = await api('/api/accounts');
    $('#flt-acc').innerHTML = '<option value="">— اختر الحساب —</option>' + d.accounts.map(a =>
      `<option value="${esc(a.acc_no)}">${esc(a.acc_no)} - ${esc(a.name)}</option>`).join('');
    $('#flt-from').value = '{{ $periodFrom }}';
    $('#flt-to').value = '{{ $periodTo }}';
    loadLedger();
  } catch (e) { toast(e.message, 'err'); }
}

function qs() {
  const p = new URLSearchParams();
  p.set('acc_no', $('#flt-acc').value.trim());
  if ($('#flt-from').value) p.set('from', $('#flt-from').value);
  if ($('#flt-to').value) p.set('to', $('#flt-to').value);
  if ($('#flt-region').value) p.set('region', $('#flt-region').value);
  return p.toString();
}

function exportLink() {
  if (!$('#flt-acc').value) return toast('اختر الحساب أولًا', 'err');
  location.href = '/ledger/export.xlsx?' + qs();
}

async function loadLedger() {
  const accNo = $('#flt-acc').value.trim();
  const box = $('#result');
  if (!accNo) {
    box.innerHTML = '<div class="empty-state"><div class="big">📖</div>اختر رقم الحساب ثم اضغط «عرض الكشف»</div>';
    return;
  }
  try {
    const d = await api('/api/ledger?' + qs());
    let rowsHtml;
    if (!d.rows.length) {
      rowsHtml = '<tr><td colspan="7" class="empty-state">لا توجد حركات في هذه الفترة</td></tr>';
    } else {
      rowsHtml = d.rows.map(r => `
        <tr>
          <td class="num">${fmtDate(r.date)}</td>
          <td class="num">${esc(r.movement_no)}</td>
          <td>${esc(r.description || '—')}</td>
          <td><span class="badge region">${esc(r.region)}</span></td>
          <td class="num text-emerald-700">${r.debit ? fmt(r.debit) : ''}</td>
          <td class="num text-rose-700">${r.credit ? fmt(r.credit) : ''}</td>
          <td class="num font-bold">${fmt(r.balance)}</td>
        </tr>`).join('');
    }
    const balClass = d.totals.balance >= 0 ? 'text-emerald-700' : 'text-rose-700';
    box.innerHTML = `
      <div class="grid grid-cols-1 gap-3 p-5 sm:grid-cols-2 xl:grid-cols-4">
        <div class="rounded-xl border border-slate-200 bg-slate-50 p-4"><div class="mb-2 text-xs font-semibold text-slate-500">الحساب</div><div class="break-words text-base font-bold text-indigo-700">${esc(d.account.name)}</div></div>
        <div class="rounded-xl border border-slate-200 bg-slate-50 p-4"><div class="mb-2 text-xs font-semibold text-slate-500">رقم الحساب</div><div class="text-base font-bold tabular-nums text-indigo-700" dir="ltr">${esc(d.account.acc_no)}</div></div>
        <div class="rounded-xl border border-slate-200 bg-slate-50 p-4"><div class="mb-2 text-xs font-semibold text-slate-500">الرصيد الافتتاحي</div><div class="text-base font-bold text-emerald-700">${fmt(d.opening)}</div></div>
        <div class="rounded-xl border border-slate-200 bg-slate-50 p-4"><div class="mb-2 text-xs font-semibold text-slate-500">الرصيد النهائي</div><div class="text-base font-bold ${balClass}">${fmt(d.totals.balance)}</div></div>
      </div>
      <div class="tbl-wrap">
        <table class="tbl">
          <thead><tr>
            <th class="num">التاريخ</th><th class="num">رقم الحركة</th><th>البيان</th><th>المنطقة</th>
            <th class="num">مدين</th><th class="num">دائن</th><th class="num">الرصيد</th>
          </tr></thead>
          <tbody>${rowsHtml}</tbody>
          <tfoot><tr>
            <td colspan="4" class="text-center">إجمالي الحركة${d.opening ? ` (بدون الرصيد الافتتاحي ${fmt(d.opening)})` : ''}</td>
            <td class="num">${fmt(d.totals.debit)}</td>
            <td class="num">${fmt(d.totals.credit)}</td>
            <td class="num ${balClass}">${fmt(d.totals.balance)}</td>
          </tr></tfoot>
        </table>
      </div>`;
  } catch (e) { toast(e.message, 'err'); }
}

init();
</script>
@endsection
