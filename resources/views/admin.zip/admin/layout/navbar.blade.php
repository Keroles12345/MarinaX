@php
    $navbarUser = auth()->user();
    $navbarName = $navbarUser
        ? ($navbarUser->full_name ?: $navbarUser->name ?: $navbarUser->username ?: 'مستخدم')
        : 'مستخدم';
@endphp

<header class="sticky top-0 z-20 border-b border-gray-100 bg-white px-4 sm:px-6 lg:px-8 {{ $isAccountingHelpPage ? 'print:hidden' : '' }}">
    <div class="flex items-center justify-between gap-4 py-4">

        <div class="flex items-center gap-4">
            <!-- Mobile / desktop menu toggle -->
            <button
                type="button"
                data-sidebar-toggle
                class="flex h-9 w-9 items-center justify-center rounded-lg text-gray-500 hover:bg-gray-50 lg:hidden"
                aria-label="Open menu"
                aria-controls="admin-sidebar"
            >
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2" class="h-6 w-6">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5M3.75 17.25h16.5" />
                </svg>
            </button>

            <span class="hidden items-center gap-2 text-sm font-medium text-gray-600 sm:flex">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.75" class="h-4 w-4 text-gray-400">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h1.5a2.25 2.25 0 0 0 2.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 0 1-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 0 0-1.091-.852H4.5A2.25 2.25 0 0 0 2.25 4.5v2.25Z" />
                </svg>
                الدعم الفني
            </span>

            <span class="hidden items-center gap-1.5 text-sm font-medium text-gray-600 md:flex">
                🇸🇦 العربية
            </span>
        </div>

        <div class="hidden flex-1 justify-center px-4 md:flex">
            <input type="text" placeholder="بحث في النظام المحاسبي" class="w-full max-w-xs rounded-lg border border-gray-200 bg-gray-50 px-4 py-2 text-sm text-gray-600 placeholder:text-gray-400 focus:border-[#3b49df] focus:outline-none focus:ring-1 focus:ring-[#3b49df]">
        </div>

        <div class="flex items-center gap-4">
            <button type="button" class="relative rounded-full p-2 text-gray-400 hover:bg-gray-50 hover:text-gray-600">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.75" class="h-5 w-5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M14.857 17.082a23.848 23.848 0 0 0 5.454-1.31A8.967 8.967 0 0 1 18 9.75V9A6 6 0 0 0 6 9v.75a8.967 8.967 0 0 1-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 0 1-5.714 0m5.714 0a3 3 0 1 1-5.714 0" />
                </svg>
            </button>
            <button type="button" class="relative rounded-full p-2 text-gray-400 hover:bg-gray-50 hover:text-gray-600">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.75" class="h-5 w-5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 0 1-2.25 2.25h-15a2.25 2.25 0 0 1-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0 0 19.5 4.5h-15a2.25 2.25 0 0 0-2.25 2.25m19.5 0v.243a2.25 2.25 0 0 1-1.07 1.916l-7.5 4.615a2.25 2.25 0 0 1-2.36 0L3.32 8.91a2.25 2.25 0 0 1-1.07-1.916V6.75" />
                </svg>
            </button>

            <!-- Profile -->
            <div class="relative shrink-0" data-profile-menu>
                <button
                    type="button"
                    data-profile-menu-toggle
                    class="flex items-center gap-2 rounded-full p-1 transition hover:bg-gray-50"
                    aria-expanded="false"
                    aria-controls="profile-menu"
                >
                    @if($navbarUser && $navbarUser->image)
                        <img class="h-9 w-9 rounded-full object-cover" src="{{ asset('storage/' . $navbarUser->image) }}" alt="{{ $navbarName }}">
                    @else
                        <div class="flex h-9 w-9 items-center justify-center rounded-full bg-[#3b49df] text-sm font-bold text-white">
                            {{ strtoupper(substr($navbarName, 0, 1)) }}
                        </div>
                    @endif
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2" class="hidden h-4 w-4 text-gray-400 sm:block">
                        <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5" />
                    </svg>
                </button>

                <div
                    id="profile-menu"
                    data-profile-menu-panel
                    class="absolute right-0 z-30 mt-2 hidden w-40 overflow-hidden rounded-xl border border-gray-100 bg-white py-1 shadow-lg"
                >
                    @if($isAccountingPage && $navbarUser && isset($navbarUser->role) && Route::has('accounting.logout'))
                        <form action="{{ route('accounting.logout') }}" method="POST">
                            @csrf
                            <button type="submit" class="flex w-full items-center gap-2 px-4 py-3 text-left text-sm font-medium text-red-600 hover:bg-red-50">
                                تسجيل الخروج
                            </button>
                        </form>
                    @elseif(Route::has('staff.logout'))
                        <form action="{{ route('staff.logout') }}" method="POST">
                            @csrf
                            <button type="submit" class="flex w-full items-center gap-2 px-4 py-3 text-left text-sm font-medium text-red-600 hover:bg-red-50">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.75" class="h-4 w-4">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0 0 13.5 3h-6a2.25 2.25 0 0 0-2.25 2.25v13.5A2.25 2.25 0 0 0 7.5 21h6a2.25 2.25 0 0 0 2.25-2.25V15M12 9l-3 3m0 0 3 3m-3-3h12.75" />
                                </svg>
                                تسجيل الخروج
                            </button>
                        </form>
                    @endif
                </div>
            </div>
        </div>
    </div>
</header>
