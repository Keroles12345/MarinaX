@php
    $navItems = $isAccountingPage ? [
        ['label' => 'لوحة المحاسبة', 'route' => 'accounting.home'],
        ['label' => 'دليل الحسابات', 'route' => 'accounts'],
        ['label' => 'شجرة الحسابات', 'route' => 'trees'],
        ['label' => 'دفتر اليومية', 'route' => 'accounting.journal'],
        ['label' => 'الأستاذ العام', 'route' => 'accounting.ledger'],
        ['label' => 'ميزان المراجعة', 'route' => 'accounting.trial-balance'],
        ['label' => 'الموازنة التقديرية', 'route' => 'accounting.budget'],
        ['label' => 'قائمة الدخل', 'route' => 'accounting.income-statement'],
        ['label' => 'المركز المالي', 'route' => 'accounting.balance-sheet'],
        ['label' => 'التدفقات النقدية', 'route' => 'accounting.cash-flow'],
        ['label' => 'دليل الاستخدام', 'route' => 'accounting.help'],
        ['label' => 'الإعدادات', 'route' => 'accounting.settings'],
    ] : [
        ['label' => 'لوحة الإدارة', 'route' => 'admin.dashboard'],
    ];
    if ($isAccountingPage && auth()->user()?->role === 'admin') {
        $navItems[] = ['label' => 'سجل العمليات', 'route' => 'accounting.audit'];
    }
    $sidebarUser = auth()->user();
    $sidebarName = $sidebarUser
        ? ($sidebarUser->full_name ?: $sidebarUser->name ?: $sidebarUser->username ?: 'مستخدم')
        : 'مستخدم';
@endphp

<!-- Mobile overlay -->
<div
    data-sidebar-overlay
    class="fixed inset-0 z-30 hidden bg-gray-900/60 lg:hidden"
></div>

<aside
    id="admin-sidebar"
    class="fixed inset-y-0 left-0 z-40 flex w-64 -translate-x-full flex-col overflow-y-auto bg-[#3b49df] text-slate-200 transition-transform duration-300 ease-in-out lg:translate-x-0 {{ $isAccountingHelpPage ? 'print:hidden' : '' }}"
>
    <!-- Brand -->
    <div class="flex items-center gap-3 px-6 py-6">
        <span class="flex h-9 w-9 items-center justify-center rounded-full bg-white/15 text-lg font-bold text-white">S</span>
        <span class="text-xl font-bold tracking-wide text-white">نظام المحاسبة</span>
    </div>

    <!-- Profile -->
    <div class="mx-4 mb-4 flex items-center gap-3 rounded-xl bg-white/10 px-4 py-3">
        <div class="relative h-10 w-10 shrink-0">
            @if($sidebarUser && $sidebarUser->image)
                <img class="h-10 w-10 rounded-full object-cover" src="{{ asset('storage/' . $sidebarUser->image) }}" alt="{{ $sidebarName }}">
            @else
                <div class="flex h-10 w-10 items-center justify-center rounded-full bg-white/20 text-sm font-bold text-white">
                    {{ strtoupper(substr($sidebarName, 0, 1)) }}
                </div>
            @endif
        </div>
        <div class="min-w-0">
            <p class="truncate text-sm font-semibold text-white">{{ $sidebarName }}</p>
            <p class="truncate text-xs text-indigo-200">{{ ['admin' => 'مدير النظام', 'accountant' => 'محاسب', 'viewer' => 'مشاهدة فقط'][$sidebarUser->role ?? ''] ?? 'المحاسبة' }}</p>
        </div>
    </div>

    <p class="px-6 pb-2 text-xs font-semibold uppercase tracking-widest text-indigo-200/70">القوائم المحاسبية</p>

    <!-- Navigation -->
    <nav class="flex-1 space-y-0.5 px-4 pb-6">
        @foreach ($navItems as $item)
            @php
                $isActive = request()->routeIs($item['route']);
                $href = Route::has($item['route']) ? route($item['route']) : '#';
            @endphp
            <a
                href="{{ $href }}"
                class="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition
                    {{ $isActive ? 'bg-white/15 text-white' : 'text-indigo-100/90 hover:bg-white/10 hover:text-white' }}"
            >
                <span class="flex h-3.5 w-3.5 items-center justify-center rounded-full border-2 border-current opacity-70"></span>
                <span class="flex-1 truncate">{{ $item['label'] }}</span>
            </a>
        @endforeach

        @if(! $isAccountingPage && Route::has('operatoins.dashboard'))
            @php($operationsActive = request()->routeIs('operatoins.dashboard'))
            <a href="{{ route('operatoins.dashboard') }}" class="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition {{ $operationsActive ? 'bg-white/15 text-white' : 'text-indigo-100/90 hover:bg-white/10 hover:text-white' }}">
                <span class="flex h-3.5 w-3.5 items-center justify-center rounded-full border-2 border-current opacity-70"></span>
                <span class="flex-1 truncate">Operations</span>
            </a>
        @endif
    </nav>

    <!-- Footer / logout -->
    @if($isAccountingPage && $sidebarUser && isset($sidebarUser->role) && Route::has('accounting.logout'))
        <div class="border-t border-white/10 p-4">
            <form action="{{ route('accounting.logout') }}" method="POST">
                @csrf
                <button type="submit" class="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-indigo-100/90 transition hover:bg-white/10 hover:text-white">
                    <span class="flex h-5 w-5 items-center justify-center">↪</span>
                    تسجيل الخروج
                </button>
            </form>
        </div>
    @elseif(Route::has('staff.logout'))
        <div class="border-t border-white/10 p-4">
            <form action="{{ route('staff.logout') }}" method="POST">
                @csrf
                <button type="submit" class="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-indigo-100/90 transition hover:bg-white/10 hover:text-white">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.75" class="h-5 w-5">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0 0 13.5 3h-6a2.25 2.25 0 0 0-2.25 2.25v13.5A2.25 2.25 0 0 0 7.5 21h6a2.25 2.25 0 0 0 2.25-2.25V15M12 9l-3 3m0 0 3 3m-3-3h12.75" />
                    </svg>
                    تسجيل الخروج
                </button>
            </form>
        </div>
    @endif
</aside>
